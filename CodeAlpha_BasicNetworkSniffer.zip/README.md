# CodeAlpha_BasicNetworkSniffer

## 🔒 Task 1: Basic Network Sniffer - CodeAlpha Internship (Cybersecurity)

This is a Python-based network packet sniffer built using the `scapy` library. It captures live packets and displays useful information like:

- ✅ Source IP
- ✅ Destination IP
- ✅ Protocol used
- ✅ Payload (if available)

## 🧪 How It Works
The program uses `scapy` to listen for network traffic and prints the contents of 10 packets to the console.

## 🚀 How to Run
1. Install `scapy`:
```
pip install scapy
```
2. Run the script:
```
python network_sniffer.py
```

Make sure to run as administrator or with `sudo` if required.

## 🔗 GitHub Repo Link
[Paste your repo link here]